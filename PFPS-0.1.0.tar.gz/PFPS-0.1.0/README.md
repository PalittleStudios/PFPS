# PFPS: Palittle First Person Shooter Library

PFPS is a Python library for FPS game development, featuring tools for importing sounds, 3D models, and images, as well as gameplay mechanics and rendering utilities.

## Installation
```bash
pip install PFPS
