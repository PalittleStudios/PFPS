class Player:
    def __init__(self, name, health, position):
        self.name = name
        self.health = health
        self.position = position
    
    def move(self, direction):
        """Move the player"""
        if direction == "forward":
            self.position[1] += 1
        elif direction == "backward":
            self.position[1] -= 1
        elif direction == "left":
            self.position[0] -= 1
        elif direction == "right":
            self.position[0] += 1
    
    def shoot(self):
        """Shoot action"""
        return f"{self.name} shoots from position {self.position}!"
