import pywavefront

def load_model(file_path):
    """Load 3D model file"""
    scene = pywavefront.Wavefront(file_path, collect_faces=True)
    return scene

def display_model_info(scene):
    """Display model details"""
    print("Vertices:", len(scene.vertices))
    print("Faces:", len(scene.mesh_list))
