import pygame

def init_screen(width, height):
    """Initialize the game screen"""
    pygame.init()
    screen = pygame.display.set_mode((width, height))
    return screen

def draw_object(screen, color, position, size):
    """Draw object on screen"""
    pygame.draw.rect(screen, color, (*position, *size))
