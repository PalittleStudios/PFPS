import pygame

def load_sound(file_path):
    """Load sound file"""
    pygame.mixer.init()
    return pygame.mixer.Sound(file_path)

def play_sound(sound):
    """Play sound"""
    sound.play()

def stop_sound(sound):
    """Stop sound"""
    sound.stop()
