from PIL import Image

def load_image(file_path):
    """Load image file"""
    img = Image.open(file_path)
    return img

def resize_image(image, width, height):
    """Resize image"""
    return image.resize((width, height))
